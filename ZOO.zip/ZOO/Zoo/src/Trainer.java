import com.animal.Animal;
public class Trainer extends Animal{
	    private String name;
	    private String location;
	    
 Trainer()
{
	
}

public void name()
{
	System.out.println("Trainer for tiger is : Tiger teja" );
	System.out.println("Location  is : Banglaore" );
	
}

}
