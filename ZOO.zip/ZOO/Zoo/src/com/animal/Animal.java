package com.animal;

import java.util.Arrays;

public class Animal implements Sound {
      String animalname;
      String birds;
      
      String[] animal= {"elephant","tiger","parrot","peaock"};
      public String toString() {
    		return "Animals present here are" +"["+ Arrays.toString(animal)+"]";
    	
      }
      public void tiger()
      {
    	  System.out.println("Tiger roar");
      }
      public void peacock()
      {
    	  System.out.println("Peacock scream");
      }
      public void elephant()
      {
    	  System.out.println("Elephant trumpet");
      }
      public void parrot()
      {
    	  System.out.println("Parrot keek");
      }
   public static void main(String args[])
      {
    	  
      }
}


