package com.animal;
public interface Sound {
    public void tiger();
    public void peacock();
    public void elephant();
    public void parrot();
   
 }
