package com.food;
public class food implements Resturant {
	
	  public void  Vegbuff()
	  {
		  System.out.println("Veg price is : 200rs");
	  }

	  public void nonvegbuff()
	  {
		  System.out.println("nonveg price is : 550rs");
	  }
	  
}


