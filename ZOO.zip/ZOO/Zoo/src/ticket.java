
public class ticket {
      double ticket;
    
public void weekday()
{
	System.out.println("Weekday price is : 700/-");
}

public void weekend()
{
	System.out.println("Weekend price is : 850/-");
}
}