import com.animal.Animal;
import com.animal.Sound;
import com.food.food;
public class zooMain {
	String zooname;
	String location="Australia";
	String time;
	String trainers;
	String visitors;
	double ticket;
	int maintanence=20;
	String res;
	
	

public static void main(String args[])
{
	Animal a =new Animal();
	food f = new food();
	
	
	}
}